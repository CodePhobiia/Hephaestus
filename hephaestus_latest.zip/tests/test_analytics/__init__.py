"""Tests for analytics helpers."""
